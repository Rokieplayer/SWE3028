# lstm-cnn-model
A LSTM CNN stock price prediction model(SP500 market)

This is an implementation of this paper: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0212320

Forcasting the stock prices is very insteresting. A lot of peoples are trying to beat the market. I'm the one of them.
I will work to evaluation this model for VN market. If you like to work with me, feel free to contact me!

